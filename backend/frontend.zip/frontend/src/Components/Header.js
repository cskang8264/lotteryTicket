import React from "react";
import { Nav, Navbar, Form, FormControl, Button } from "react-bootstrap";
import logo from "../logo.png";
import { HashRouter as Router, Link } from "react-router-dom";

class Header extends React.Component {
  render() {
    return (
      <div>
        <Navbar bg="white" expand="lg">
          <Navbar.Brand href="/">
            <img src={logo} style={{ width: "3em", height: "3em" }}></img>
          </Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="mr-auto">
              <Router>
                <Nav.Link href="/">홈</Nav.Link>
                <Nav.Link href="/board">게시판</Nav.Link>
                <Nav.Link>
                  <Link to="/login" style={{ color: "#000" }}>
                    로그인
                  </Link>
                </Nav.Link>
                <Nav.Link>
                  <Link to="/signup" style={{ color: "#000" }}>
                    회원가입
                  </Link>
                </Nav.Link>
                <Nav.Link href="/timesale">타임세일</Nav.Link>
                <Nav.Link>
                  <Link to="/mypage" style={{ color: "#000" }}>
                    마이페이지
                  </Link>
                </Nav.Link>
              </Router>
            </Nav>
            <Form inline>
              <FormControl
                type="text"
                placeholder="Search"
                className="mr-sm-2"
              />
              <Button variant="outline-success">Search</Button>
            </Form>
          </Navbar.Collapse>
        </Navbar>
      </div>
    );
  }
}

export default Header;